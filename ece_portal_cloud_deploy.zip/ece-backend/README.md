# 🎓 GPT Chintamani ECE Portal — Setup Guide

Two ways to run this app with **real multi-device sync**:

---

## Option B — Netlify (Frontend only, no sync between phones)

> Best for sharing the UI. Each phone still has its own data.

1. Go to **https://netlify.com** → Sign up free
2. Drag & drop the `ece_portal_v2.html` file onto the Netlify dashboard
3. Netlify gives you a URL like `https://ece-portal-abc123.netlify.app`
4. Share that URL — both phones open the same file ✓
5. **Limitation:** data is still per-device (no sync)

---

## Option C — Full Backend (Real sync across all phones) ⭐ Recommended

### Requirements
- A PC/laptop running **24/7** OR a cloud server (free options below)
- **Node.js 16+** installed → https://nodejs.org

### Step 1 — Install & Run on your PC

```bash
# Extract the ece-backend folder, then:
cd ece-backend
npm install
node server.js
```

You'll see:
```
🎓 ECE Portal Backend running at:
   Local:   http://localhost:3000
   Network: http://192.168.1.5:3000  ← use this on phones
```

### Step 2 — Put the frontend file in the right place

Copy `ece_portal_v2.html` → rename it to `index.html` → place inside `ece-backend/public/`

```
ece-backend/
├── server.js
├── package.json
├── public/
│   └── index.html    ← renamed ece_portal_v2.html
└── ece_portal.db     ← auto-created on first run
```

### Step 3 — Open on any phone on same Wi-Fi

1. Find your PC's IP: run `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
2. On each phone open: `http://YOUR_PC_IP:3000`
3. All phones now share the **same database** in real time ✓

---

## Option C2 — Free Cloud Hosting (Access from anywhere, any network)

### Render.com (Free tier — easiest)

1. Push the `ece-backend` folder to a GitHub repo
2. Go to **https://render.com** → New → Web Service
3. Connect your GitHub repo
4. Settings:
   - **Build command:** `npm install`
   - **Start command:** `node server.js`
5. Deploy → get a URL like `https://ece-portal.onrender.com`
6. All phones worldwide can access it ✓

### Railway.app (Also free)

1. Go to **https://railway.app**
2. New Project → Deploy from GitHub repo
3. Add environment variable: `PORT=3000`
4. Deploy ✓

---

## Default Login Credentials

| Role    | Email                          | Password    |
|---------|--------------------------------|-------------|
| Admin   | admin@gpchintamani.edu         | admin123    |
| Admin   | cr2109474@gmail.com            | admin123    |
| Teacher | teacher@gpchintamani.edu       | teacher123  |
| Student | student@gpchintamani.edu       | student123  |

---

## How the app works

```
Phone 1 ──┐
Phone 2 ──┤──► Node.js Server ──► SQLite Database (ece_portal.db)
Phone 3 ──┘         ↑
                  (your PC or cloud server)
```

- When backend is **online**: all data syncs across all devices instantly
- When backend is **offline**: app automatically falls back to localStorage (no data loss)
- A green dot appears in the header when connected to the backend

---

## File Structure

```
ece-backend/
├── server.js          ← Main backend (Express + SQLite)
├── package.json       ← Dependencies
├── netlify.toml       ← For Netlify frontend-only hosting
├── ece_portal.db      ← SQLite database (auto-created)
└── public/
    └── index.html     ← Rename ece_portal_v2.html to this
```

---

## API Endpoints (for reference)

| Method | Endpoint               | Description              |
|--------|------------------------|--------------------------|
| POST   | /api/auth/login        | Login → get JWT token    |
| GET    | /api/users             | All users                |
| POST   | /api/users             | Add user (admin)         |
| GET    | /api/attendance        | Attendance records       |
| POST   | /api/attendance        | Mark attendance          |
| GET    | /api/marks             | Marks                    |
| POST   | /api/marks             | Add/update marks         |
| GET    | /api/messages          | Chat messages            |
| POST   | /api/messages          | Send message             |
| GET    | /api/notices           | Notices                  |
| POST   | /api/notices           | Create notice (admin)    |
| GET    | /api/timetable         | Timetable                |
| GET    | /api/project-groups    | Project groups           |
| GET    | /api/notifications     | Notifications            |
| GET    | /api/health            | Server health check      |

---

## Need Help?

WhatsApp the backend server URL to all students/teachers once it's running — they just open it in their phone browser and everything syncs automatically.
